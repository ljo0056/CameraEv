# Rtsp-live555-Ffmpeg-opencv
这可能只是一个测试版本
＃LIVE555的库需要自己安装ffmpeg,opencv
＃该程序在linuxubuntu16.04.3亲测有效
